"""Host-created availability proofs; event and observation cutoffs stay separate."""
from datetime import date, datetime, time, timedelta
from typing import Literal
from zoneinfo import ZoneInfo

from pydantic import model_validator

from ..contracts import Contract


def aware(value):
    if value.tzinfo is None or value.utcoffset() is None:
        raise ValueError("timezone-aware timestamp required")
    return value


class Boundary(Contract):
    event_cutoff: datetime
    snapshot_at: datetime
    market_timezone: str

    @model_validator(mode="after")
    def valid(self):
        aware(self.event_cutoff)
        aware(self.snapshot_at)
        ZoneInfo(self.market_timezone)
        if self.snapshot_at < self.event_cutoff:
            raise ValueError("snapshot precedes event cutoff")
        return self


class Availability(Contract):
    event_at: datetime
    available_at: datetime
    fetched_at: datetime
    version_public_at: datetime | None
    time_quality: Literal["received_at", "timestamp_verified", "date_only_next_date", "observed_only", "derived", "committed_receipt", "historical_publication_declared", "publication_declared"]

    @model_validator(mode="after")
    def valid(self):
        for value in (self.event_at, self.available_at, self.fetched_at, self.version_public_at):
            if value is not None:
                aware(value)
        if self.version_public_at is not None and self.available_at < self.version_public_at:
            raise ValueError("availability precedes current version publication")
        return self

    def visible(self, boundary):
        deadline = (boundary.snapshot_at if self.time_quality in {"committed_receipt", "historical_publication_declared", "derived"}
                    else boundary.event_cutoff)
        return self.event_at <= boundary.event_cutoff and self.available_at <= deadline


def mx_availability(*, received_at, source_created_at):
    return Availability(event_at=source_created_at or received_at, available_at=received_at,
                        fetched_at=received_at, version_public_at=None, time_quality="received_at")


def publication_availability(*, event_at, fetched_at, first_public_at, version_public_at, trusted):
    if trusted and first_public_at is not None and version_public_at is not None:
        if version_public_at < first_public_at:
            raise ValueError("version precedes first publication")
        available, quality = max(first_public_at, version_public_at), "timestamp_verified"
        if fetched_at < available:
            raise ValueError("collection precedes publication")
    else:
        available, quality = fetched_at, "observed_only"
    return Availability(event_at=event_at, available_at=available, fetched_at=fetched_at,
                        version_public_at=version_public_at, time_quality=quality)


def dated_availability(*, event_at, fetched_at, published_on: date, version_on: date, source_timezone):
    if version_on < published_on:
        raise ValueError("version precedes first publication date")
    available = datetime.combine(version_on + timedelta(days=1), time.min, ZoneInfo(source_timezone))
    return Availability(event_at=event_at, available_at=available, fetched_at=fetched_at,
                        version_public_at=available, time_quality="date_only_next_date")


def derived_availability(dependencies):
    dependencies = tuple(dependencies)
    if not dependencies:
        raise ValueError("derived product requires all dependency availability proofs")
    return Availability(event_at=max(max(item.event_at, item.available_at) if item.time_quality in
                                         {"received_at", "timestamp_verified", "date_only_next_date", "observed_only", "publication_declared"}
                                         else item.event_at for item in dependencies),
                        available_at=max(item.available_at for item in dependencies),
                        fetched_at=max(item.fetched_at for item in dependencies),
                        version_public_at=max((item.version_public_at for item in dependencies if item.version_public_at is not None), default=None),
                        time_quality="derived")


def receipt_availability(*, committed_at, receipt_latency_ms):
    if type(receipt_latency_ms) is not int or receipt_latency_ms < 0:
        raise ValueError("receipt latency must be nonnegative milliseconds")
    return Availability(event_at=committed_at, available_at=committed_at + timedelta(milliseconds=receipt_latency_ms),
                        fetched_at=committed_at, version_public_at=None, time_quality="committed_receipt")
