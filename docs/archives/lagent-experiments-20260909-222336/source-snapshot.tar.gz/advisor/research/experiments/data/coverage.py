"""Whole-task security/date/scenario coverage. Daily data never implies queue readiness."""
from collections import Counter
from datetime import datetime, timedelta
from decimal import Decimal
from zoneinfo import ZoneInfo

from ..contracts import ExperimentDraft
from ..resolution import digest, resolve
from .contracts import MarketRule, FeeSchedule


def queue_quality(snapshots, events, expected):
    reasons = []
    snapshots = [item for item in snapshots if item["row"].payload["session"] == expected["session"]]
    if len(snapshots) != 1 or not snapshots[0]["row"].payload["complete"] or not expected["complete"]:
        return ["queue_snapshot_or_completeness_missing"]
    initial = snapshots[0]["row"]
    start_at, end_at = datetime.fromisoformat(expected["start_at"]), datetime.fromisoformat(expected["end_at"])
    if initial.event_at != start_at:
        reasons.append("queue_snapshot_time_mismatch")
    if initial.payload["last_sequence"] + 1 != expected["start_sequence"]:
        reasons.append("queue_initial_sequence_mismatch")
    selected = sorted((item["row"] for item in events if item["row"].payload["session"] == expected["session"]), key=lambda row: row.payload["sequence"])
    seqs = [row.payload["sequence"] for row in selected]
    if seqs != list(range(expected["start_sequence"], expected["end_sequence"] + 1)):
        return [*reasons, "queue_event_sequence_gap"]
    book = {order["order_id"]: dict(order) for order in initial.payload["orders"]}
    if len(book) != len(initial.payload["orders"]) or len({o["priority"] for o in book.values()}) != len(book):
        return [*reasons, "queue_initial_priority_ambiguous"]
    last_time = initial.event_at
    try:
        for row in selected:
            event = row.payload
            if row.event_at < last_time or row.event_at > end_at:
                raise ValueError("queue event time regressed")
            last_time = row.event_at
            identity, quantity = event["order_id"], event["quantity"]
            if event["event_type"] == "add":
                if identity in book:
                    raise ValueError("duplicate queue order")
                book[identity] = {"quantity": quantity, "side": event["side"], "price": event["price"], "priority": event["sequence"]}
                continue
            if identity not in book or book[identity]["side"] != event["side"] or book[identity]["quantity"] < quantity:
                raise ValueError("queue consumption has no matching order")
            if event["event_type"] == "match":
                contra = event["contra_order_id"]
                if contra not in book or contra == identity or book[contra]["side"] == event["side"] or book[contra]["quantity"] < quantity:
                    raise ValueError("queue match has no reconstructable counterparty")
                buy = book[identity] if event["side"] == "buy" else book[contra]
                sell = book[contra] if event["side"] == "buy" else book[identity]
                if not Decimal(sell["price"]) <= Decimal(event["price"]) <= Decimal(buy["price"]):
                    raise ValueError("queue match violates historical limits")
                book[contra]["quantity"] -= quantity
                if book[contra]["quantity"] == 0:
                    del book[contra]
            book[identity]["quantity"] -= quantity
            if book[identity]["quantity"] == 0:
                del book[identity]
    except (ValueError, KeyError, TypeError):
        reasons.append("queue_reconstruction_failed")
    return reasons


def coverage_report(bundles, bundle_id, raw_spec):
    record, manifest = bundles.read(bundle_id)
    spec = ExperimentDraft.model_validate(raw_spec)
    zone = ZoneInfo(spec.clock.timezone)
    initial = min(datetime.combine(task.research_start_date, spec.clock.initial_research_at, zone) for task in spec.tasks)
    resolution = resolve(raw_spec, calendar=bundles.calendar(bundle_id, as_of=initial))
    issues, cells = [], []
    def issue(code, **scope):
        issues.append({"code": code, **scope})
    if spec.data.bundle_ref != manifest.bundle_ref or spec.clock.timezone != manifest.market_timezone:
        issue("bundle_binding_mismatch")
    if resolution.specification is None:
        issues.extend(error.model_dump(mode="json") for error in resolution.errors)
    declared = {day.trade_date: day for day in manifest.coverage}
    rules = {item["row"].row_id: item for item in bundles.rows(bundle_id, "rules")}
    fees = {item["row"].row_id: item for item in bundles.rows(bundle_id, "fees")}
    sources = {source.source_id: source for source in manifest.sources}
    source_refs = set(sources)
    tasks = resolution.specification.tasks if resolution.specification else ()
    for task in tasks:
        for day in task.trading_dates:
            cutoff = datetime.combine(day, spec.clock.auction_as_of, zone)
            close_cutoff = datetime.combine(day, spec.clock.postmarket_as_of, zone)
            expectation = declared.get(day)
            universe = list(bundles.rows(bundle_id, "universe", day=day))
            present = {item["row"].security for item in universe}
            if expectation is None:
                issue("historical_universe_proof_missing", task_id=task.task_id, trade_date=day.isoformat())
                continue
            proof = sources[expectation.universe_proof_ref]
            if proof.semantics != "historical_publication" or proof.published_at > cutoff:
                issue("historical_universe_proof_unavailable", task_id=task.task_id, trade_date=day.isoformat())
            if present != set(expectation.securities):
                issue("historical_universe_coverage_mismatch", task_id=task.task_id, trade_date=day.isoformat(),
                      missing=sorted(set(expectation.securities) - present), unexpected=sorted(present - set(expectation.securities)))
            for security in expectation.securities:
                failures = []
                entries = [item for item in universe if item["row"].security == security]
                if len(entries) != 1:
                    cells.append({"task_id": task.task_id, "trade_date": day.isoformat(), "security": security,
                                  "status": "blocked", "blocking_codes": ["historical_universe_row_missing"]})
                    continue
                selected = entries[0]
                membership = selected["row"].payload
                if selected["available_at"] > cutoff:
                    failures.append("universe_not_historically_available")
                rule_entry, fee_entry = rules.get(membership["market_rule_ref"]), fees.get(membership["fee_ref"])
                rule = None
                if rule_entry is None:
                    failures.append("market_rule_missing")
                else:
                    rule = MarketRule.model_validate(rule_entry["row"].payload)
                    if (not rule.effective_from <= day <= rule.effective_to or rule_entry["available_at"] > cutoff
                            or any(getattr(rule, key) != membership[key] for key in ("exchange", "board", "state"))
                            or not set(rule.official_source_refs) <= source_refs):
                        failures.append("market_rule_binding_invalid")
                if fee_entry is None:
                    failures.append("fee_schedule_missing")
                else:
                    fee = FeeSchedule.model_validate(fee_entry["row"].payload)
                    if not fee.effective_from <= day <= fee.effective_to or fee.exchange != membership["exchange"] or fee_entry["available_at"] > cutoff or not set(fee.official_source_refs) <= source_refs:
                        failures.append("fee_schedule_binding_invalid")
                groups = {dataset: list(bundles.rows(bundle_id, dataset, day=day, security=security))
                          for dataset in ("daily", "minute", "auction", "queue", "queue_snapshot", "status", "corporate_actions")}
                if len(groups["status"]) != 1:
                    failures.append("security_status_missing")
                if len(groups["corporate_actions"]) != 1 or not groups["status"] or not groups["status"][0]["row"].payload["corporate_actions_complete"]:
                    failures.append("corporate_action_coverage_missing")
                if len(groups["daily"]) != 1:
                    failures.append("raw_close_valuation_missing")
                for dataset, rows in groups.items():
                    if any(item["available_at"] > close_cutoff for item in rows):
                        failures.append(dataset + "_late_or_unproved_version")
                scenarios = {}
                status = groups["status"][0]["row"].payload if groups["status"] else None
                if status and status["trading"] == "suspended":
                    if status["suspension_evidence_ref"] not in source_refs:
                        failures.append("suspension_evidence_missing")
                    scenarios["execution"] = "not_applicable_full_suspension"
                elif rule is not None and status is not None:
                    starts = {datetime.fromisoformat(item["row"].payload["interval_start"]).astimezone(zone).isoformat() for item in groups["minute"]}
                    expected_starts = set()
                    for interval in rule.continuous:
                        minute = datetime.combine(day, interval.start, zone)
                        while minute < datetime.combine(day, interval.end, zone):
                            expected_starts.add(minute.isoformat())
                            minute += timedelta(seconds=rule.minute_seconds)
                    if starts != expected_starts:
                        failures.append("continuous_minute_coverage_missing")
                    if status["trading"] == "partial_halt":
                        failures.append("partial_halt_interval_rules_unresolved")
                    required_sessions = {"open", "continuous", "close"} | ({"resume"} if status["trading"] == "partial_halt" else set())
                    queue_ranges = {span["session"]: span for span in status["queue_ranges"]}
                    if len(queue_ranges) != len(status["queue_ranges"]):
                        failures.append("queue_range_ambiguous")
                    for session in sorted(required_sessions):
                        errors = (queue_quality(groups["queue_snapshot"], groups["queue"], queue_ranges[session])
                                  if session in queue_ranges else ["execution_evidence_missing"])
                        interval = (rule.opening_auction if session == "open" else rule.closing_auction if session == "close" else None)
                        if session in queue_ranges and session != "resume":
                            span = queue_ranges[session]
                            required_start = datetime.combine(day, interval.start if interval else rule.continuous[0].start, zone)
                            required_end = datetime.combine(day, interval.end if interval else rule.continuous[-1].end, zone)
                            if datetime.fromisoformat(span["start_at"]) > required_start or datetime.fromisoformat(span["end_at"]) < required_end:
                                errors.append("queue_time_coverage_missing")
                        scenarios[session] = "passed" if not errors else "blocked"
                        failures.extend(session + ":" + error for error in errors)
                    for session in ("open", "close"):
                        auctions = [item for item in groups["auction"] if item["row"].payload["session"] == session]
                        if len(auctions) != 1:
                            failures.append(session + "_auction_result_missing")
                            continue
                        auction = auctions[0]
                        boundary = (datetime.combine(day, spec.clock.postauction_as_of, zone) if session == "open" else close_cutoff)
                        event_boundary = datetime.combine(day, rule.opening_auction.end if session == "open" else rule.closing_auction.end, zone)
                        if auction["available_at"] > boundary or auction["row"].event_at != event_boundary:
                            failures.append(session + "_auction_late_or_wrong_event_time")
                        volume = sum(item["row"].payload["quantity"] for item in groups["queue"]
                                     if item["row"].payload["session"] == session and item["row"].payload["event_type"] == "match")
                        if volume != auction["row"].payload["volume"]:
                            failures.append(session + "_auction_queue_volume_mismatch")
                cells.append({"task_id": task.task_id, "trade_date": day.isoformat(), "security": security,
                              "status": "blocked" if failures else "passed", "scenarios": scenarios,
                              "blocking_codes": sorted(set(failures)), "counts": {key: len(value) for key, value in groups.items()}})
    blocked = bool(issues) or any(cell["status"] != "passed" for cell in cells) or not cells
    return {"schema_version": 1, "bundle_id": bundle_id, "manifest_hash": record["value"]["manifest_hash"],
            "origin": manifest.origin, "coverage_status": "blocked" if blocked else "passed",
            "source_acceptance": record["value"]["source_acceptance"],
            "formal_ready": False, "formal_blockers": ["fixture_not_real_evidence" if manifest.origin == "fixture" else "independent_source_and_rule_review_required"],
            "requested_tasks": [task.model_dump(mode="json") for task in spec.tasks],
            "resolved_tasks": [task.model_dump(mode="json") for task in tasks], "issues": issues, "cells": cells,
            "summary": dict(Counter(cell["status"] for cell in cells)), "model_calls": 0, "return": None}
