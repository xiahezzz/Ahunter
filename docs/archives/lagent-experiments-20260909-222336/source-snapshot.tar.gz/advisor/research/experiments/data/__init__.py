"""Host-only immutable historical bundles; never a live Market Daily provider."""
