"""Phase-bound host query boundary. Never hand this object to candidate code.

The future runtime RPC dispatcher binds a session once and accepts only tool
arguments. Runtime OS/filesystem/network containment is a separate prerequisite.
"""
from dataclasses import dataclass
from datetime import date
import json
from typing import Callable, Iterable
from zoneinfo import ZoneInfo

from pydantic import model_validator

from ..contracts import Contract, Name, PositiveInt
from ..records import Fenced
from ..registration import record_identity
from ..repository import Conflict
from ..resolution import digest, encode
from .temporal import Availability, Boundary


class DataRequest(Contract):
    product: Name
    security: Name | None = None
    start: date
    end: date
    limit: PositiveInt

    @model_validator(mode="after")
    def ordered(self):
        if self.end < self.start:
            raise ValueError("invalid date interval")
        return self


@dataclass(frozen=True)
class ProductItem:
    item_id: str
    security: str | None
    day: date
    availability: Availability
    value: dict
    effective_from: date | None = None
    effective_to: date | None = None


@dataclass(frozen=True)
class Product:
    product_ref: str
    version: str
    required: bool
    read: Callable[[DataRequest], Iterable[ProductItem]]


@dataclass(frozen=True)
class PhaseScope:
    experiment_id: str
    test_id: str
    phase_id: str
    generation: int
    boundary: Boundary


class PhaseSession:
    """Host-owned identity; children share data scope, never plan-submission authority."""
    def __init__(self, records, scope, *, actor_id, assert_active):
        test = records.read(scope.test_id)
        if test["kind"] != "test" or test["experiment_id"] != scope.experiment_id:
            raise Conflict("phase session requires a test in the same experiment")
        self.records, self.scope = records, scope
        self.actor_id, self._assert_active = actor_id, assert_active
        self.is_child = False

    def check(self):
        self._assert_active(self.scope)

    def child(self, actor_id):
        self.check()
        child = PhaseSession(self.records, self.scope, actor_id=actor_id, assert_active=self._assert_active)
        child.is_child = True
        return child

    def audit(self, request, result, *, action_id, audit_result=None):
        self.check()
        identity = [self.scope.test_id, self.scope.phase_id, self.scope.generation, self.actor_id, action_id]
        artifact = self.records.artifacts.put_json(result if audit_result is None else audit_result)
        prepared = self.records.prepare(experiment_id=self.scope.experiment_id, kind="query",
            record_id=record_identity(self.scope.experiment_id, "query", identity),
            submission_identity=digest(identity),
            value={"phase_id": self.scope.phase_id, "generation": self.scope.generation,
                   "actor_id": self.actor_id, "request": request,
                   "boundary": self.scope.boundary.model_dump(mode="json"), "response_hash": artifact.content_hash},
            links=(("test", self.scope.test_id),), artifact_hashes=(artifact.content_hash,))
        with self.records._transaction():
            self.check()
            self.records._insert(prepared)
        self.check()
        return json.loads(encode(result))


def unavailable(code, *, required):
    return {"status": "blocked" if required else "unavailable", "code": code, "items": [],
            "blocks_scoring": required}


class HistoricalQueries:
    def __init__(self, session, products):
        self.session = session
        products = tuple(products)
        self._products = {p.product_ref: p for p in products}
        if len(self._products) != len(products):
            raise ValueError("duplicate product grants")

    def catalog(self):
        self.session.check()
        # No live coverage counts, source paths, hidden dates, or host catalog.
        return [{"product": p.product_ref, "version": p.version, "required": p.required}
                for p in self._products.values()]

    def child(self, actor_id):
        return HistoricalQueries(self.session.child(actor_id), tuple(self._products.values()))

    def query(self, arguments, *, action_id):
        self.session.check()
        try:
            request = DataRequest.model_validate(arguments)
        except (ValueError, TypeError):
            return self.session.audit({"rejected_request_hash": digest(arguments)}, unavailable("invalid_query", required=False), action_id=action_id)
        product = self._products.get(request.product)
        if product is None:
            return self.session.audit({"rejected_request_hash": digest(arguments)}, unavailable("product_not_permitted", required=False), action_id=action_id)
        boundary = self.session.scope.boundary
        if request.end > boundary.event_cutoff.astimezone(ZoneInfo(boundary.market_timezone)).date():
            result = unavailable("query_outside_observation_boundary", required=product.required)
        else:
            try:
                visible = []
                for item in product.read(request):
                    if not request.start <= item.day <= request.end or (request.security is not None and item.security != request.security):
                        continue
                    if not item.availability.visible(boundary):
                        continue
                    business_day = boundary.event_cutoff.astimezone(ZoneInfo(boundary.market_timezone)).date()
                    if ((item.effective_from is not None and business_day < item.effective_from)
                            or (item.effective_to is not None and business_day > item.effective_to)):
                        continue
                    visible.append({"item_id": item.item_id, "security": item.security, "day": item.day.isoformat(),
                                    "time": item.availability.model_dump(mode="json"), "value": item.value})
                visible.sort(key=lambda item: (item["day"], item["item_id"]))
                # Never reveal the number or identity of filtered future rows.
                result = ({"status": "available", "items": visible[:request.limit], "has_more": len(visible) > request.limit,
                           "blocks_scoring": False} if visible else unavailable("product_unavailable_at_boundary", required=product.required))
            except Fenced:
                raise
            except Exception:
                # Provider exception text can contain a future price, URL or host path.
                result = unavailable("product_quality_failure", required=product.required)
        return self.session.audit(request.model_dump(mode="json"), result, action_id=action_id)


def bundle_product(bundles, bundle_id, dataset, *, product_ref, required):
    record, _ = bundles.read(bundle_id)
    def read(request):
        for item in bundles.rows(bundle_id, dataset, security=request.security):
            row = item["row"]
            day = row.trade_date or request.end
            market_evidence = dataset in {"daily", "minute", "auction", "queue", "queue_snapshot"}
            timing = Availability(event_at=row.event_at, available_at=item["available_at"], fetched_at=row.collected_at,
                version_public_at=row.version_public_at,
                time_quality="observed_only" if item["time_quality"] == "observed_only" else "historical_publication_declared" if market_evidence else "publication_declared")
            yield ProductItem(row.row_id, row.security, day, timing, row.payload,
                              date.fromisoformat(row.payload["effective_from"]) if "effective_from" in row.payload else None,
                              date.fromisoformat(row.payload["effective_to"]) if "effective_to" in row.payload else None)
    return Product(product_ref, record["value"]["manifest_hash"], required, read)
