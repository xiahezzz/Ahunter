"""Stream local bundles into immutable artifacts and a host-only SQLite index."""
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3
import tempfile
from zoneinfo import ZoneInfo

from ..candidates import _source_path
from ..contracts import CalendarResolution
from ..registration import record_identity
from ..repository import Conflict
from ..resolution import digest, encode
from .contracts import BundleManifest, HistoricalRow, PAYLOADS


class BundleInvalid(ValueError):
    def __init__(self, issues, failure_record_id=None):
        self.issues = issues
        self.failure_record_id = failure_record_id
        super().__init__("historical bundle validation failed")


def strict_json(value):
    def object_pairs(pairs):
        result = {}
        for key, item in pairs:
            if key in result:
                raise ValueError("duplicate JSON field")
            result[key] = item
        return result
    def invalid_constant(value):
        raise ValueError("non-finite JSON number")
    return json.loads(value, object_pairs_hook=object_pairs, parse_constant=invalid_constant)


def utc(value):
    return value.astimezone(timezone.utc).isoformat()


def validate_row(raw, file, manifest):
    row = HistoricalRow.model_validate(raw)
    payload = PAYLOADS[file.dataset].model_validate(row.payload)
    zone = ZoneInfo(file.timestamp_timezone)
    for value in (row.event_at, row.published_at, row.version_public_at, row.collected_at):
        if value is not None and value.utcoffset() != value.astimezone(zone).utcoffset():
            raise ValueError("timestamp offset contradicts declared source timezone")
    if file.dataset not in {"rules", "fees"} and row.trade_date is None:
        raise ValueError("dataset requires trade_date")
    if row.trade_date is not None and not manifest.coverage_start <= row.trade_date <= manifest.coverage_end:
        raise ValueError("row date lies outside manifest coverage")
    if file.dataset not in {"calendar", "rules", "fees"} and row.security is None:
        raise ValueError("dataset requires a security identity")
    if file.dataset in {"calendar", "rules", "fees"} and row.security is not None:
        raise ValueError("reference dataset cannot carry a security identity")
    if file.dataset in {"daily", "minute", "auction", "queue", "queue_snapshot"}:
        if row.event_at.astimezone(ZoneInfo(manifest.market_timezone)).date() != row.trade_date:
            raise ValueError("event time contradicts market trade_date")
    if file.dataset in {"daily", "minute"}:
        if row.event_at != payload.interval_end:
            raise ValueError("price event time must equal interval end")
        if file.dataset == "minute" and (payload.interval_end - payload.interval_start).total_seconds() != 60:
            raise ValueError("minute data requires a complete sixty-second interval")
    sources = {source.source_id: source for source in manifest.sources}
    proved = (file.time_semantics == "historical_publication" and row.published_at is not None
              and row.version_public_at is not None
              and all(sources[ref].semantics == "historical_publication" for ref in file.proof_refs))
    if proved:
        base = max(row.published_at, row.version_public_at)
        if file.dataset in {"daily", "minute", "auction", "queue", "queue_snapshot"}:
            base = max(base, row.event_at)
        available = base + timedelta(milliseconds=file.publication_latency_ms)
        quality = "historical_publication_declared"
    else:
        available, quality = row.collected_at, "observed_only"
    day, security = row.trade_date.isoformat() if row.trade_date else None, row.security
    if file.dataset == "minute":
        key = [security, day, utc(payload.interval_start)]
    elif file.dataset in {"queue", "queue_snapshot"}:
        key = [security, day, payload.session, payload.sequence if file.dataset == "queue" else "snapshot"]
    elif file.dataset == "auction":
        key = [security, day, payload.session, utc(row.event_at)]
    elif file.dataset in {"rules", "fees"}:
        key = [row.row_id]
    else:
        key = [security, day]
    return row, payload, utc(available), quality, encode(key)


class HistoricalBundles:
    def __init__(self, records):
        self.records = records
        self.artifacts = records.artifacts

    def _seal_file(self, root, path, expected_hash):
        source = _source_path(root, path)
        descriptor, name = tempfile.mkstemp(dir=self.artifacts.staging_dir, prefix="bundle-")
        import os
        os.close(descriptor)
        staged = Path(name)
        try:
            shutil.copyfile(source, staged)
            if self.artifacts._hash_file(staged) != expected_hash:
                raise ValueError("bundle file content hash differs from manifest")
            return self.artifacts.adopt_file(staged)
        finally:
            staged.unlink(missing_ok=True)

    def import_bundle(self, experiment_id, root, *, submission_identity):
        root = Path(root).resolve(strict=True)
        manifest_bytes = _source_path(root, "manifest.json").read_bytes()
        manifest_ref = self.artifacts.put_bytes(manifest_bytes, media_type="application/json")
        try:
            manifest = BundleManifest.model_validate(strict_json(manifest_bytes))
        except (ValueError, TypeError) as exc:
            issues = [{"code": "invalid_bundle_manifest", "error_type": type(exc).__name__}]
            failure = self._failure(experiment_id, submission_identity, manifest_ref.content_hash, issues)
            raise BundleInvalid(issues, failure["record_id"]) from exc
        refs, issues = [manifest_ref.content_hash], []
        for source in manifest.sources:
            try:
                refs.append(self._seal_file(root, source.path, source.content_hash).content_hash)
            except (OSError, ValueError):
                issues.append({"code": "source_evidence_missing_or_corrupt", "path": source.path})
        for file in manifest.files:
            try:
                refs.append(self._seal_file(root, file.path, file.sha256).content_hash)
            except (OSError, ValueError):
                issues.append({"code": "bundle_file_missing_or_corrupt", "path": file.path})
        if issues:
            failure = self._failure(experiment_id, submission_identity, manifest_ref.content_hash, issues)
            raise BundleInvalid(issues, failure["record_id"])
        bundle_id = record_identity(experiment_id, "bundle", manifest.bundle_ref)
        value = {"manifest": manifest.model_dump(mode="json"), "manifest_artifact_hash": manifest_ref.content_hash,
                 "manifest_hash": digest(manifest), "source_acceptance": "fixture_only" if manifest.origin == "fixture" else "pending_independent_review",
                 "adapter": "local_historical_bundle_v1", "execution_available": False}
        prepared = self.records.prepare(experiment_id=experiment_id, kind="data_bundle", record_id=bundle_id,
                                        submission_identity=submission_identity, value=value, artifact_hashes=refs)
        try:
            with self.records._transaction():
                existed = self.records.db.execute("SELECT 1 FROM lagent_records WHERE record_id=?", (bundle_id,)).fetchone() is not None
                registered = self.records._insert(prepared)
                if existed:
                    return registered
                for file in manifest.files:
                    count, hashed = 0, hashlib.sha256()
                    target = self.artifacts._path_for(file.sha256)
                    with target.open("rb") as stream:
                        for count, line in enumerate(stream, 1):
                            hashed.update(line)
                            try:
                                raw = strict_json(line)
                                row, payload, available, quality, key = validate_row(raw, file, manifest)
                            except (ValueError, TypeError) as exc:
                                raise BundleInvalid([{"code": "invalid_historical_row", "path": file.path, "line": count,
                                                      "error_type": type(exc).__name__}]) from exc
                            self.records.db.execute("INSERT INTO lagent_bundle_rows (bundle_id, dataset, row_id, natural_key, security, trade_date, event_at, available_at, time_quality, file_hash, value_json, value_hash) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                                                    (bundle_id, file.dataset, row.row_id, key, row.security,
                                                     row.trade_date.isoformat() if row.trade_date else None,
                                                     utc(row.event_at), available, quality, file.sha256, encode(row), digest(row)))
                            self.records.fault("after_bundle_row")
                    if hashed.hexdigest() != file.sha256 or count != file.row_count:
                        raise BundleInvalid([{"code": "bundle_row_count_or_hash_mismatch", "path": file.path}])
                return registered
        except (BundleInvalid, sqlite3.IntegrityError) as exc:
            details = exc.issues if isinstance(exc, BundleInvalid) else [{"code": "duplicate_historical_identity"}]
            failure = self._failure(experiment_id, submission_identity, manifest_ref.content_hash, details)
            raise BundleInvalid(details, failure["record_id"]) from exc

    def _failure(self, experiment_id, identity, manifest_hash, issues):
        return self.records.put(experiment_id=experiment_id, kind="bundle_import",
                         record_id=record_identity(experiment_id, "bundle-import-failure", [identity, manifest_hash, issues]),
                         submission_identity=digest([identity, manifest_hash, issues]),
                         value={"status": "blocked", "manifest_artifact_hash": manifest_hash, "issues": issues},
                         artifact_hashes=(manifest_hash,))

    def read(self, bundle_id):
        record = self.records.read(bundle_id)
        if record["kind"] != "data_bundle":
            raise Conflict("expected historical bundle record")
        manifest = BundleManifest.model_validate(record["value"]["manifest"])
        if digest(manifest) != record["value"]["manifest_hash"]:
            raise Conflict("bundle manifest integrity failure")
        return record, manifest

    def rows(self, bundle_id, dataset, *, day=None, security=None):
        _, manifest = self.read(bundle_id)
        for stored in self.records.db.execute(
                "SELECT value_json, value_hash, available_at, time_quality, file_hash FROM lagent_bundle_rows "
                "WHERE bundle_id=? AND dataset=? AND (? IS NULL OR trade_date=?) AND (? IS NULL OR security=?) "
                "ORDER BY event_at, row_id", (bundle_id, dataset, str(day) if day else None, str(day) if day else None, security, security)):
            value = self.records._checked(stored[0], stored[1])
            files = [file for file in manifest.files if file.dataset == dataset and file.sha256 == stored[4]]
            if len(files) != 1:
                raise Conflict("bundle index lacks an unambiguous sealed source file")
            row, _, available, quality, _ = validate_row(value, files[0], manifest)
            if available != stored[2] or quality != stored[3]:
                raise Conflict("bundle index time metadata differs from sealed source semantics")
            yield {"row": row, "available_at": datetime.fromisoformat(stored[2]), "time_quality": stored[3], "file_hash": stored[4]}

    def preflight(self, bundle_id, raw_spec, *, submission_identity):
        """Seal a diagnostic coverage export; this never grants execution readiness."""
        from .coverage import coverage_report
        record, _ = self.read(bundle_id)
        report = coverage_report(self, bundle_id, raw_spec)
        report["requested_specification_hash"] = digest(raw_spec)
        artifact = self.artifacts.put_json(report)
        experiment_id = record["experiment_id"]
        return self.records.put(
            experiment_id=experiment_id, kind="preflight",
            record_id=record_identity(experiment_id, "bundle-coverage", submission_identity),
            submission_identity=submission_identity,
            value={"scope": "historical_bundle_coverage", "bundle_id": bundle_id,
                   "status": "blocked", "coverage_status": report["coverage_status"],
                   "formal_ready": report["formal_ready"], "report_hash": artifact.content_hash},
            links=(("data_bundle", bundle_id),), artifact_hashes=(artifact.content_hash,))

    def calendar(self, bundle_id, *, as_of):
        record, manifest = self.read(bundle_id)
        if as_of.tzinfo is None or as_of.utcoffset() is None:
            raise ValueError("calendar cutoff must be timezone-aware")
        rows = list(self.rows(bundle_id, "calendar"))
        # Resolution uses the original sealed rows, not merely a self-consistent
        # mutable index. Verify every calendar file and compare the indexed copy.
        original = {}
        for file in manifest.files:
            if file.dataset != "calendar":
                continue
            raw_lines = self.artifacts.read_bytes(file.sha256).splitlines()
            if len(raw_lines) != file.row_count:
                raise Conflict("sealed calendar file row count changed")
            for line in raw_lines:
                row, _, _, _, _ = validate_row(strict_json(line), file, manifest)
                if row.row_id in original:
                    raise Conflict("sealed calendar has duplicate row identities")
                original[row.row_id] = row
        if original != {item["row"].row_id: item["row"] for item in rows}:
            raise Conflict("calendar index differs from original sealed rows")
        days = {item["row"].trade_date: item for item in rows}
        complete = all(manifest.coverage_start + timedelta(days=i) in days
                       for i in range((manifest.coverage_end - manifest.coverage_start).days + 1))
        complete = complete and all(item["available_at"] <= as_of for item in days.values())
        sessions = tuple(sorted(day for day, item in days.items() if item["row"].payload["is_open"]))
        evidence = CalendarResolution(calendar_ref=manifest.calendar_ref, content_hash=digest([record["value"]["manifest_hash"], [item["row"] for item in rows]]),
                                      coverage_start=manifest.coverage_start, coverage_end=manifest.coverage_end,
                                      sessions=sessions, complete=complete)
        def provider(ref, period):
            if ref != manifest.calendar_ref:
                raise ValueError("calendar reference does not match imported bundle")
            return evidence
        return provider
