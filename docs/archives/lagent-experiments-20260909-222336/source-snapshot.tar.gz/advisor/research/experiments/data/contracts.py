"""Historical bundle wire format. Unproved publication times fall back to collection."""
from datetime import date, datetime, time
from decimal import Decimal
from typing import Annotated, Literal
from zoneinfo import ZoneInfo

from pydantic import Field, model_validator

from ..contracts import Contract, Hash, Name, NonnegativeInt, PositiveInt, PositiveDecimal, Money, numeric_field

Dataset = Literal["calendar", "universe", "daily", "minute", "auction", "queue", "queue_snapshot", "status", "corporate_actions", "rules", "fees"]


class EvidenceSource(Contract):
    source_id: Name
    path: str
    publisher: str = Field(min_length=1)
    url: str = Field(min_length=1)
    content_hash: Hash
    published_at: datetime
    retrieved_at: datetime
    semantics: Literal["historical_publication", "observed_only"]

    @model_validator(mode="after")
    def aware(self):
        for value in (self.published_at, self.retrieved_at):
            if value.tzinfo is None or value.utcoffset() is None:
                raise ValueError("evidence timestamps must be timezone-aware")
        if self.retrieved_at < self.published_at:
            raise ValueError("evidence cannot be retrieved before publication")
        return self


class BundleFile(Contract):
    path: str
    dataset: Dataset
    sha256: Hash
    row_count: NonnegativeInt = numeric_field("row")
    timestamp_timezone: str
    time_semantics: Literal["historical_publication", "observed_only"]
    proof_refs: tuple[Name, ...]
    publication_latency_ms: NonnegativeInt = numeric_field("millisecond")

    @model_validator(mode="after")
    def time_zone(self):
        try:
            ZoneInfo(self.timestamp_timezone)
        except (KeyError, ValueError) as exc:
            raise ValueError("unknown source timestamp timezone") from exc
        if self.time_semantics == "historical_publication" and not self.proof_refs:
            raise ValueError("historical time semantics require source evidence")
        return self


class CoverageDay(Contract):
    trade_date: date
    securities: tuple[Name, ...] = Field(min_length=1)
    universe_proof_ref: Name

    @model_validator(mode="after")
    def unique(self):
        if len(set(self.securities)) != len(self.securities):
            raise ValueError("coverage securities must be unique")
        return self


class BundleManifest(Contract):
    schema_version: Literal[1]
    adapter: Literal["local_historical_bundle_v1"]
    bundle_ref: Name
    origin: Literal["fixture", "real"]
    calendar_ref: Name
    coverage_start: date
    coverage_end: date
    market_timezone: str
    sources: tuple[EvidenceSource, ...]
    files: tuple[BundleFile, ...] = Field(min_length=1)
    coverage: tuple[CoverageDay, ...]

    @model_validator(mode="after")
    def coherent(self):
        if self.coverage_end < self.coverage_start:
            raise ValueError("invalid bundle coverage interval")
        try:
            ZoneInfo(self.market_timezone)
        except (KeyError, ValueError) as exc:
            raise ValueError("unknown market timezone") from exc
        if len({file.path for file in self.files}) != len(self.files):
            raise ValueError("bundle file paths must be unique")
        sources = {source.source_id for source in self.sources}
        if len(sources) != len(self.sources):
            raise ValueError("source identities must be unique")
        if any(not set(file.proof_refs) <= sources for file in self.files):
            raise ValueError("unknown file proof reference")
        if any(day.universe_proof_ref not in sources for day in self.coverage):
            raise ValueError("unknown universe coverage evidence")
        if len({day.trade_date for day in self.coverage}) != len(self.coverage):
            raise ValueError("duplicate universe coverage day")
        if any(not self.coverage_start <= day.trade_date <= self.coverage_end for day in self.coverage):
            raise ValueError("universe coverage day outside bundle interval")
        return self


class HistoricalRow(Contract):
    row_id: Name
    security: Name | None
    trade_date: date | None
    event_at: datetime
    published_at: datetime | None
    version_public_at: datetime | None
    collected_at: datetime
    payload: dict

    @model_validator(mode="after")
    def timestamp_contract(self):
        for value in (self.event_at, self.published_at, self.version_public_at, self.collected_at):
            if value is not None and (value.tzinfo is None or value.utcoffset() is None):
                raise ValueError("row timestamps must be timezone-aware")
        if self.published_at is not None and self.version_public_at is not None and self.version_public_at < self.published_at:
            raise ValueError("revision publication precedes original publication")
        if any(value is not None and value > self.collected_at for value in (self.published_at, self.version_public_at)):
            raise ValueError("collection precedes publication")
        return self


class CalendarPayload(Contract):
    is_open: bool = Field(strict=True)


class UniversePayload(Contract):
    exchange: Literal["SH", "SZ"]
    board: Literal["main", "star", "chinext"]
    security_type: Literal["a_share"]
    state: Literal["normal", "st", "ipo", "delisting"]
    market_rule_ref: Name
    fee_ref: Name


class PricePayload(Contract):
    open: PositiveDecimal = numeric_field("CNY_per_share")
    high: PositiveDecimal = numeric_field("CNY_per_share")
    low: PositiveDecimal = numeric_field("CNY_per_share")
    close: PositiveDecimal = numeric_field("CNY_per_share")
    volume: NonnegativeInt = numeric_field("share")
    volume_unit: Literal["share"]
    adjustment: Literal["raw"]
    interval_start: datetime
    interval_end: datetime

    @model_validator(mode="after")
    def prices_and_interval(self):
        if not self.low <= min(self.open, self.close) <= max(self.open, self.close) <= self.high:
            raise ValueError("inconsistent OHLC prices")
        if any(v.tzinfo is None or v.utcoffset() is None for v in (self.interval_start, self.interval_end)) or self.interval_start >= self.interval_end:
            raise ValueError("invalid price interval")
        return self


class AuctionPayload(Contract):
    session: Literal["open", "close", "resume"]
    price: PositiveDecimal | None = numeric_field("CNY_per_share", null="no match")
    volume: NonnegativeInt = numeric_field("share")
    volume_unit: Literal["share"]

    @model_validator(mode="after")
    def matched(self):
        if (self.price is None) != (self.volume == 0):
            raise ValueError("auction price must agree with matched volume")
        return self


class QueueOrder(Contract):
    order_id: Name
    side: Literal["buy", "sell"]
    price: PositiveDecimal = numeric_field("CNY_per_share")
    quantity: PositiveInt = numeric_field("share")
    priority: NonnegativeInt = numeric_field("exchange_priority_sequence")


class QueueSnapshot(Contract):
    session: Literal["open", "continuous", "close", "resume"]
    complete: bool = Field(strict=True)
    last_sequence: NonnegativeInt = numeric_field("per_security_sequence")
    orders: tuple[QueueOrder, ...]


class QueueEvent(Contract):
    session: Literal["open", "continuous", "close", "resume"]
    event_type: Literal["add", "cancel", "match"]
    sequence: NonnegativeInt = numeric_field("per_security_sequence")
    order_id: Name
    contra_order_id: Name | None
    side: Literal["buy", "sell"]
    price: PositiveDecimal = numeric_field("CNY_per_share")
    quantity: PositiveInt = numeric_field("share")


class QueueRange(Contract):
    start_at: datetime
    end_at: datetime
    session: Literal["open", "continuous", "close", "resume"]
    start_sequence: NonnegativeInt = numeric_field("per_security_sequence")
    end_sequence: NonnegativeInt = numeric_field("per_security_sequence")
    complete: bool = Field(strict=True)


    @model_validator(mode="after")
    def bounded(self):
        if any(v.tzinfo is None or v.utcoffset() is None for v in (self.start_at, self.end_at)) or self.end_at <= self.start_at:
            raise ValueError("queue evidence requires an explicit aware time interval")
        if self.end_sequence < self.start_sequence - 1:
            raise ValueError("queue evidence sequence interval is invalid")
        return self


class StatusPayload(Contract):
    trading: Literal["active", "suspended", "partial_halt"]
    queue_ranges: tuple[QueueRange, ...]
    corporate_actions_complete: bool = Field(strict=True)
    suspension_evidence_ref: Name | None


class CorporateAction(Contract):
    action_id: Name
    kind: Literal["dividend", "bonus", "split", "rights", "delisting", "merger"]
    record_date: date
    effective_date: date
    payment_date: date | None
    tradable_date: date | None
    cash_per_share: Money | None = numeric_field("CNY_per_share", null="not a cash event")
    shares_ratio: Money | None = numeric_field("share_per_old_share", null="not a share event")
    rule_ref: Name


class CorporateActionsPayload(Contract):
    actions: tuple[CorporateAction, ...]


class TradingInterval(Contract):
    start: time
    end: time

    @model_validator(mode="after")
    def ordered(self):
        if self.start.tzinfo or self.end.tzinfo or self.start >= self.end:
            raise ValueError("invalid local trading interval")
        return self


class MarketRule(Contract):
    exchange: Literal["SH", "SZ"]
    board: Literal["main", "star", "chinext"]
    state: Literal["normal", "st", "ipo", "delisting"]
    effective_from: date
    effective_to: date
    official_source_refs: tuple[Name, ...] = Field(min_length=1)
    tick: PositiveDecimal = numeric_field("CNY_per_share")
    buy_minimum: PositiveInt = numeric_field("share")
    buy_increment: PositiveInt = numeric_field("share")
    maximum_order_quantity: PositiveInt = numeric_field("share")
    fill_increment: PositiveInt = numeric_field("share")
    price_limit_fraction: Annotated[Decimal, Field(gt=0, le=1)] | None = numeric_field("fraction", null="no price limit")
    price_cage_fraction: Money | None = numeric_field("fraction", null="not applicable")
    price_cage_ticks: NonnegativeInt | None = numeric_field("tick", null="not applicable")
    bought_shares_sell_lag: NonnegativeInt = numeric_field("trading_session")
    sold_cash_reuse_lag: NonnegativeInt = numeric_field("trading_session")
    sold_cash_withdraw_lag: NonnegativeInt = numeric_field("trading_session")
    continuous: tuple[TradingInterval, ...] = Field(min_length=1)
    opening_auction: TradingInterval
    closing_auction: TradingInterval
    accept_orders: tuple[TradingInterval, ...] = Field(min_length=1)
    cancel_forbidden: tuple[TradingInterval, ...]
    minute_seconds: Literal[60] = numeric_field("second")

    @model_validator(mode="after")
    def coherent(self):
        if self.effective_to < self.effective_from or self.maximum_order_quantity < self.buy_minimum:
            raise ValueError("invalid market rule interval or quantity")
        if any(left.end > right.start for left, right in zip(self.continuous, self.continuous[1:])):
            raise ValueError("overlapping continuous intervals")
        return self


class FeeItem(Contract):
    fee_id: Name
    side: Literal["buy", "sell", "both"]
    basis: Literal["turnover"]
    rate: Money = numeric_field("fraction_of_turnover")
    minimum: Money = numeric_field("CNY_per_order")
    quantum: PositiveDecimal = numeric_field("CNY")
    rounding: Literal["ROUND_HALF_UP"]
    included_in_commission: bool = Field(strict=True)


class FeeSchedule(Contract):
    exchange: Literal["SH", "SZ"]
    effective_from: date
    effective_to: date
    official_source_refs: tuple[Name, ...] = Field(min_length=1)
    items: tuple[FeeItem, ...] = Field(min_length=1)

    @model_validator(mode="after")
    def complete_unique(self):
        if self.effective_to < self.effective_from:
            raise ValueError("invalid fee schedule period")
        ids = [item.fee_id for item in self.items]
        if len(ids) != len(set(ids)) or not {"stamp_duty", "transfer_fee"} <= set(ids):
            raise ValueError("duplicate or missing statutory fee items")
        return self


PAYLOADS = {"calendar": CalendarPayload, "universe": UniversePayload, "daily": PricePayload,
            "minute": PricePayload, "auction": AuctionPayload, "queue": QueueEvent,
            "queue_snapshot": QueueSnapshot, "status": StatusPayload,
            "corporate_actions": CorporateActionsPayload, "rules": MarketRule, "fees": FeeSchedule}
