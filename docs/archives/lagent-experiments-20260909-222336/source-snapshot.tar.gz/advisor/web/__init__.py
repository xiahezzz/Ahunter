"""Local advisor web API."""
